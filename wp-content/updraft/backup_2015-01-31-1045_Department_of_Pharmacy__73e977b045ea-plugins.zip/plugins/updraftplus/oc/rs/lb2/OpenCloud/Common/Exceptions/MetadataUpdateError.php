<?php

namespace OpenCloud\Common\Exceptions;

class MetadataUpdateError extends \Exception {}
