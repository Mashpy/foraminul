<?php

namespace OpenCloud\Common\Exceptions;

class ServerUpdateError extends \Exception {}
