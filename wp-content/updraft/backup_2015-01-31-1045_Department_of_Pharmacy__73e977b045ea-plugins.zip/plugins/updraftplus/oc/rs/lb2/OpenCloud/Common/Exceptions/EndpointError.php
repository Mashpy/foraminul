<?php

namespace OpenCloud\Common\Exceptions;

class EndpointError extends \Exception {}
