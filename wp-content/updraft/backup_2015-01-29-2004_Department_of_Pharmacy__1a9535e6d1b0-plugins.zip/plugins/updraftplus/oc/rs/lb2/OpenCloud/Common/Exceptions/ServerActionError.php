<?php

namespace OpenCloud\Common\Exceptions;

class ServerActionError extends \Exception {}
