<?php

namespace OpenCloud\Common\Exceptions;

class CreateError extends \Exception {}
