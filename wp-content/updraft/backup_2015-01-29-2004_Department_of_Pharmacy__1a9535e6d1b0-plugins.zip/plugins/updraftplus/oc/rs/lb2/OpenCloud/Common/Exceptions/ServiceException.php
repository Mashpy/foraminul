<?php

namespace OpenCloud\Common\Exceptions;

class ServiceException extends \Exception {}
