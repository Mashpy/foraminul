<?php

namespace OpenCloud\Common\Exceptions;

class UserUpdateError extends \Exception {}
