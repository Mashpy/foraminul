<?php

namespace OpenCloud\Common\Exceptions;

class ContainerError extends \Exception {}
